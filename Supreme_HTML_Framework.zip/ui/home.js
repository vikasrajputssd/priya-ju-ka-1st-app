// 🖼 UI Layer
window.render=()=>{
 if(State.screen==='home'){
  document.getElementById('app').innerHTML=`
   <h1>🔥 Supreme HTML Framework</h1>
   <button data-action="home">Home</button>
  `;
 }
};

document.addEventListener('click',e=>{
 if(e.target.dataset.action){
  Router.go(e.target.dataset.action);
 }
});