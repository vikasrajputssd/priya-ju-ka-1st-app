// 👑 State = King
window.State={
 screen:'home'
};

window.setState=(obj)=>{
 Object.assign(State,obj);
 render();
};