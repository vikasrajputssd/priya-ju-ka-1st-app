// 🧭 Central Router
window.Router={
 go(action){
   Actions.map[action]?.();
 }
};