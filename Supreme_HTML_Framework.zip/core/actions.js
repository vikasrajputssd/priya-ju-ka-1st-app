// 🧠 Logic Map
window.Actions={
 map:{
  home:()=>setState({screen:'home'})
 }
};