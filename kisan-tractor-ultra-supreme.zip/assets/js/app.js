document.addEventListener("DOMContentLoaded",()=>{
const $=id=>document.getElementById(id);
let records=JSON.parse(localStorage.getItem("records"))||[];

const home=$("homeCard"), tractor=$("tractorPage"), list=$("listPage");

$("openTractor").onclick=()=>{
  home.classList.add("hidden");
  tractor.classList.remove("hidden");
};

function calc(){
  if(!$("startTime").value||!$("endTime").value||!$("rate").value)return null;
  let[sH,sM]=$("startTime").value.split(":").map(Number);
  let[eH,eM]=$("endTime").value.split(":").map(Number);
  let s=sH*60+sM,e=eH*60+eM;if(e<s)e+=1440;
  let hr=(e-s)/60,amt=Math.round(hr*$("rate").value);
  $("totalTime").textContent=hr.toFixed(2)+" घंटे";
  $("totalAmount").textContent="₹ "+amt;
  localStorage.setItem("lastRate",$("rate").value);
  return{hr:hr.toFixed(2),amt};
}

$("endTime").onchange=calc;
$("rate").oninput=calc;
$("rate").value=localStorage.getItem("lastRate")||"";

$("saveRecord").onclick=()=>{
  let d=calc(); if(!d)return;
  records.push({id:Date.now(),hr:d.hr,amt:d.amt});
  localStorage.setItem("records",JSON.stringify(records));
  render();
  tractor.classList.add("hidden");
  list.classList.remove("hidden");
};

function render(){
  let total=0, html="";
  records.forEach(r=>{
    total+=r.amt;
    html+=`<tr><td>${r.hr}</td><td>₹${r.amt}</td><td><button data-id="${r.id}">❌</button></td></tr>`;
  });
  $("recordList").innerHTML=html;
  $("dayTotal").textContent="₹ "+total;
}

$("recordList").onclick=e=>{
  if(e.target.tagName!=="BUTTON")return;
  records=records.filter(r=>r.id!=e.target.dataset.id);
  localStorage.setItem("records",JSON.stringify(records));
  render();
};

$("backHome").onclick=()=>{
  list.classList.add("hidden");
  home.classList.remove("hidden");
};

render();
});