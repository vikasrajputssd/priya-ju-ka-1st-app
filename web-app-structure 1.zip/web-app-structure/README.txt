यह web app की base structure है।
