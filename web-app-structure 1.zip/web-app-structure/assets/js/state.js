/* =========================================================
   STATE.JS
   क्यों:
   - App की स्थिति एक ही जगह रहे
   - Random variables फैलें नहीं
   ========================================================= */

/*
  AppState
  क्यों:
  - पूरा data object के अंदर
  - Future में localStorage / API जोड़ना आसान
*/
const AppState = {
  userName: null,      // अभी नहीं, future-ready
  isOnline: true,      // network status
};