// AUTO RATE LOAD
$("rate").value = localStorage.getItem("lastRate") || "";

// SAVE RATE
$("rate").onchange = () => {
  localStorage.setItem("lastRate", $("rate").value);
};

// DATE FILTER
$("filterDate").onchange = () => render($("filterDate").value);

// EDIT MODE
let editId = null;

function render(filterDate=null){
  const list = $("recordList");
  list.innerHTML="";
  let day=0, month=0;
  const now = new Date();

  records.forEach(r=>{
    const rDate = new Date(r.date).toISOString().split("T")[0];
    if(filterDate && rDate!==filterDate) return;

    day += r.amount;
    if(new Date(r.date).getMonth()===now.getMonth()) month+=r.amount;

    const tr=document.createElement("tr");
    tr.innerHTML=`
      <td>${r.name}</td>
      <td>${r.work}</td>
      <td>${r.hours}</td>
      <td>₹${r.amount}</td>
      <td><button class="edit-btn" data-id="${r.id}">✏️</button></td>
      <td><button data-id="${r.id}">❌</button></td>
    `;
    list.appendChild(tr);
  });

  $("dayTotal").textContent=`₹ ${day}`;
  $("monthTotal").textContent=`₹ ${month}`;
}

// EDIT CLICK
$("recordList").onclick = (e)=>{
  const id = e.target.dataset.id;
  if(!id) return;

  if(e.target.textContent==="✏️"){
    const r = records.find(x=>x.id==id);
    editId = id;
    $("customerName").value = r.name;
    $("workType").value = r.work;
    $("rate").value = r.amount;
    home.classList.add("hidden");
    tractor.classList.remove("hidden");
  }

  if(e.target.textContent==="❌"){
    records = records.filter(r=>r.id!=id);
    save(); render();
  }
};

// ADD / UPDATE
$("addRecordBtn").onclick = ()=>{
  const data = calculate();
  if(!data) return;

  if(editId){
    const r = records.find(x=>x.id==editId);
    r.name=$("customerName").value;
    r.work=$("workType").value;
    r.hours=data.hours;
    r.amount=data.amount;
    editId=null;
  }else{
    records.push({
      id:Date.now(),
      date:new Date(),
      name:$("customerName").value,
      work:$("workType").value,
      hours:data.hours,
      amount:data.amount
    });
  }

  save(); render();
  tractor.classList.add("hidden");
  listPage.classList.remove("hidden");
};