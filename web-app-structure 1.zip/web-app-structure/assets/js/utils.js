/* =========================================================
   UTILS.JS
   क्यों:
   - बार-बार होने वाला logic एक जगह
   - app.js साफ रहता है
   ========================================================= */

/*
  DOM से element सुरक्षित तरीके से लेना
  क्यों:
  - Error कम
  - Code readable
*/
function $(selector) {
  return document.querySelector(selector);
}

/*
  Text set करने का safe तरीका
  क्यों:
  - बाद में sanitization जोड़ना आसान
*/
function setText(el, text) {
  if (el) el.textContent = text;
}