const scene=new THREE.Scene();
scene.fog=new THREE.Fog(0x000000,5,25);
const camera=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,0.1,100);
camera.position.set(0,3,6);
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight);
document.body.appendChild(renderer.domElement);
const light=new THREE.DirectionalLight(0xffddaa,2);
light.position.set(5,10,5);scene.add(light);
const ground=new THREE.Mesh(new THREE.BoxGeometry(6,0.1,100),
new THREE.MeshStandardMaterial({color:0x222222}));
ground.position.z=-40;scene.add(ground);
const player=new THREE.Mesh(new THREE.BoxGeometry(0.6,1,0.6),
new THREE.MeshStandardMaterial({color:0xffffff,emissive:0x222222}));
player.position.y=0.5;scene.add(player);
let mantra=new THREE.Mesh(new THREE.SphereGeometry(0.3,32,32),
new THREE.MeshStandardMaterial({color:0xffaa00,emissive:0xff6600}));
scene.add(mantra);
let jap=0;const counter=document.getElementById("count");
let lane=0;
addEventListener("keydown",e=>{if(e.key==="ArrowLeft")lane=-1;if(e.key==="ArrowRight")lane=1;});
function resetMantra(){mantra.position.set((Math.random()*2-1)*2,0.6,-20);}
resetMantra();
function animate(){requestAnimationFrame(animate);
mantra.position.z+=0.2;
player.position.x+=(lane*2-player.position.x)*0.1;
if(player.position.distanceTo(mantra.position)<0.7){
jap++;counter.innerText=jap;resetMantra();}
if(mantra.position.z>5)resetMantra();
renderer.render(scene,camera);}
animate();
